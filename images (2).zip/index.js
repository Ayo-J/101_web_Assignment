function redirectToYouTube() {
    window.location.href = "https://www.youtube.com";
  }